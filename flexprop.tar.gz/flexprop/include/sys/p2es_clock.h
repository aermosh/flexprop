#pragma once

// crystal frequency
#define _XTALFREQ 20000000
// XOSC: 0 == off, 1 == OSC, 2 == 15pF, 3 == 30pF
#define _XOSC 2

#include "p2_clock.h"
