#ifndef _SYS_LIMITS_H
#define _SYS_LIMITS_H

#pragma once

#define _NAME_MAX (64)
#define _PATH_MAX (256)

#endif
