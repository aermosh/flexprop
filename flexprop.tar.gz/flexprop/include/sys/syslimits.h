#ifndef _SYSLIMITS_H
#define _SYSLIMITS_H

/* some POSIX definitions */
#define OPEN_MAX 8
#define PATH_MAX 256

#endif
