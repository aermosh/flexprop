#ifndef _SIZE_T

#ifndef __SIZE_TYPE__
#define __SIZE_TYPE__ unsigned long
#endif
  typedef __SIZE_TYPE__ size_t;
#define _SIZE_T
#endif
