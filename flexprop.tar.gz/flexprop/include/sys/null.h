#ifndef NULL
#define NULL (0)
#endif
