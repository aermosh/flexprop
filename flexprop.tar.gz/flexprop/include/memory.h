#ifndef _MEMORY_H
#define _MEMORY_H

#include <compiler.h>
#include <string.h>

#endif
