#ifndef _COG_H_
#define _COG_H_

#pragma once

#ifndef __FLEXC__
extern unsigned int _clkfreq;
#endif

#define _CLKFREQ _clkfreq

#endif
